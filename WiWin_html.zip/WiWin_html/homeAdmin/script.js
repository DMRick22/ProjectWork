$(document).on("click", ".navbar-right .dropdown-menu", function(e){
	e.stopPropagation();
});